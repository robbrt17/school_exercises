#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("input.txt");

int main() {
    int n;
    int m[100][100];
    int cont = 0;

    fin>>n;

    for(int i = 1; i <= n; i++)
        for(int j = 1; j <= n; j++)
            fin >> m[i][j];

    for(int i = 1; i <= n; i++) {
        for(int j = 1; j <= n; j++) {
            if(m[i][j] == 1) {
                cont++;
            }
        }
    }

    cout << n << endl;
    cout << cont/2 << endl;

    for(int i = 1; i <= n; i++)
        for(int j = 1; j <= n; j++)
        {
            if(i < j)
                if(m[i][j] == 1)
                    cout << i << " " << j << endl;
        }

    fin.close();

    return 0;
 }

