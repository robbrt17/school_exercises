//palindrom

#include <iostream>
#include <string.h>
#include <algorithm>

using namespace std;

string mystring;
string stringcopy;

int main() {
    getline(cin, mystring);
    stringcopy.assign(mystring.rbegin(), mystring.rend());

    if (mystring == stringcopy) {
        cout << "palindrom";
    } else {
        cout << "nah";
    }

    return 0;
}
