#include <iostream>
#include <string.h>

using namespace std;

int main() {
    char s[256];
    cin.get(s, 256);
    char caracter;
    cin >> caracter;
    int frecventa = 0;

    if (isupper(caracter)) {
        caracter += 32;
    }

    for (int i = 0; i < strlen(s); i++) {
        s[i] = tolower(s[i]);
        if (s[i] == caracter) {
            frecventa++;
        }
    }

    cout << frecventa;

    return 0;
}
