#include <iostream>
#include <fstream>
#include <stdlib.h>
#include <string.h>

using namespace std;

ifstream fin("input.txt");

int main() {
    char s[101];
    fin.get(s, 101);

    for (int i = 0; i < strlen(s); i++) {
        if (!isalpha(s[i])) {
            cout << s[i];

            if (isalpha(s[i+1])) {
                cout << endl;
            }
        }
    }

    return 0;
}
