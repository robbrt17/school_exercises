#include <iostream>
#include <string.h>

using namespace std;

int main() {
    char s[101], *p[101];
    int j, i, n = 0;

    cin.get(s, 101);
    cout << endl;

    p[0] = strtok(s, " ");

    while (p[n]) {
        n++;
        p[n] = strtok(NULL, " ");
    }

    //cout << n;

    for (i = 0; i < n; i++) {
        for (j = (i+1); j < n; j++) {
            if (strcmp(p[i], p[j]) > 0) {
                swap (p[i], p[j]);
            }
        }
    }

    for (i = 0; i < n; i++) {
        cout << p[i] << " ";
    }

    return 0;
}
