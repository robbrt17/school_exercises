#include <iostream>
#include <string.h>

using namespace std;

int main() {
    char s[101];
    cin.get(s, 101);
    int n = 0;

    for (int i = 0; i < strlen(s); i++) {
        if (isspace(s[i])) {
            n++;
        }

        if (s[i] == '.') {
            n++;
        }
    }

    cout << n;

    return 0;
}
